var resourceName = context.getVariable("payloadVars.resourceType");
var resourceType = capitalizeFirstLetter(resourceName.toLowerCase());
print("resourceType:"+ resourceType); // logging 
var id = context.getVariable("payloadVars.id");
print("id:"+ id); // logging

//Retrieve the vendor query parameter from the requedt
var vendor = context.getVariable("request.queryparam.vendor");
print("vendor: "+ vendor) //logging

//Remove the vendor query parameter from the request(we dont need to send)
context.removeVariable("request.queryparam.vendor");


var objectName = resourceType + "-" + id + ".json";
var vendorFolder = vendor ? vendor + "/" : "";
var filename = vendorFolder + objectName


context.setVariable("filename", filename);
print("filename to upload object to the storage:"+ filename);//logging

function capitalizeFirstLetter(string) {
    return string[0].toUpperCase() + string.slice(1);
}


