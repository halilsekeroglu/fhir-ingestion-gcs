name = flow.getVariable("payloadVars.resourceType")
filename = str(name).split("/")[-1]
flow.setVariable("filename",filename)

print("111111111111111111111111111111111")