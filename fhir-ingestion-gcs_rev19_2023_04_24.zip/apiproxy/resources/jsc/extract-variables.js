var resourceName = context.getVariable("payloadVars.resourceType");
var resourceType = capitalizeFirstLetter(resourceName.toLowerCase())
print("resourceType:"+ resourceType); // logging 
var id = context.getVariable("payloadVars.id");
print("id:"+ id)
var filename = resourceType + "-" + id;
context.setVariable("filename", filename)
print("filename to upload object to the storage:"+ filename);//logging

function capitalizeFirstLetter(string) {
    return string[0].toUpperCase() + string.slice(1);
}












// var errorCode = "400"
// var errorMessage = "Invalid request" + resourceType
// var errorInfo = "https://developers.myapi.com"
// var errorStatus = "400"
// var errorReason = "Bad Request"


// var errorH = {
//     "code": errorCode,
//     "message": errorMessage,
//     "info": errorInfo,
//     "status": errorStatus,
//     "reason": errorReason
// }


// context.setVariable("errh", errorH)

// //PRINTING
// print("errh.......:"+ errorH)

// var a = context.getVariable("errh")
// print("ErrorObjectsAfterSetContext:"+ a.code)



























// var value = context.getVariable('system.time.year')
// var requestCode = properties.source // Returns "response.status.code"
// var value = context.getVariable(requestCode); // Get the value of response.status.code
// var gender = context.getVariable("request.content.gender")
// var startPeriod = context.getVariable("request.content.period.start")

// print("startPeriod:"+ startPeriod)

// print("value is here"+ value)
// print("Request Code:" + requestCode)
// print("Gender" + gender)







// if (context.flow=="PROXY_REQ_FLOW") {
//      print("In proxy request flow");
//      var username = context.getVariable("request.queryparam.user");
//      print("Got query param: " + username);
//      context.setVariable("USER.name", username);
//      print("Set query param: " + context.getVariable("USER.name"));
// }


// if (context.flow=="TARGET_REQ_FLOW") {
//      print("In target request flow");
//      var username = context.getVariable("USER.name");
//      var url = "http://mocktarget.apigee.net/user?"
//      context.setVariable("target.url", url + "user=" + username);
//      print("callout to URL: ", context.getVariable("target.url"));
// }